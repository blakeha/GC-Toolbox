$ErrorActionPreference = 'Stop'
Import-Module LsSetupHelper\Packages\Shared\App